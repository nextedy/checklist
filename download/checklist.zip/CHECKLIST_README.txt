com.nextedy.polarion.checklist
==============================
Detailed README: com.nextedy.polarion.checklist/README.txt
Installation instructions: com.nextedy.polarion.checklist/INSTALL.txt
Licensing information: com.nextedy.polarion.checklist/LICENSE.pdf

