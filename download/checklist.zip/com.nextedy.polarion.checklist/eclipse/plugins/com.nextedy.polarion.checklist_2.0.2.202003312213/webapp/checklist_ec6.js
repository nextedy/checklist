/**
 * @class Model
 * 
 * Manages the data of the application.
 */
//https://babeljs.io/repl#?browsers=&build=&builtIns=false&spec=false&loose=false&code_lz=PQKhCgAIUgBBjANgQwM6sgWQPYBMCmiUMxWyAdsgOb4YAuAFvpLsncpNgGaSPPIAHAYgCW8NiOzkAdMWDgkaDDgKJIAbyiR4U1HQBOAV3h1s-gBQjyIuq3YAaHeTr5njqV3cBbLzYASFLiI-PoAlBrgAJDAwE6o2MHSiNhU5gBEAsj6qFZULGwcXGYAXGkA1E5c0vBcAHLIXsxlkGmQALwtZVY2dhyhANxakLwMIqjVHu3aHoPDw4xj0t22BVPLvbNzC-OmuNgYHQBSAMoA8rXSmdn4ltYr7OEAPo-QANoAupvzo-NXqPgAYSkLmc5icILo9gMhnwoSGI0WOh8_kCwX0bSRvjoAXIQRCmwAvlokPgsuZQppIt9Frt9lNttJaeMuCJEC4LLT2gA-Xh4bDSLj6bBeAAq-C8wjYsKi1J2fIOCLle3GXkE5k5bS5MsgkUi0OYAH4NCJcMVeXslrh7JAUAAjQhm2lJZD2xDW-BMeAAa3wpsgXGQiH-kGtqtxbDMAE9ik6w3Yo9bBcKxRKUC4Y3yBULReLJS4CZBiuoiVSdZE4aWGZibOqfoz5XDhkThgB9Gh0AEAMXqjXJlOG-nwdEM-nIiom5CqNR7-C0zcgWhbf3wtWwLnMonI-HsNnF4X7cwAbllIOQxQAPOhTTf4aSoQy2vT6XIbqy3qwEc-nLjpLlpUJlAAjAMUSRLuXjSOQa7MB0lguBBUEuJARrgZB0GQGUaQADrkK0ZRnvgl6FqeF50CBuqDsOo68EYs6RPOcxREuWT_AAMm-r5bvYVyuGRESlsMIg_jxzgAIRtOQhiIGoABkMk2m-0iqnQHrpAAetAf6hPuoFgT-DLMdcq7rje3FZLx2n8bqkSUSOY4iXQgzWSW9GRKBx76ApW4AApZHQCo3newg1thdD_k5kQebwhFXh0N4RVFcYRvokZTAGQb4AlJ4evg3q-mlgb_FlnlbgA7gAkvB9K0f0uqgUJnH4L5-j-UkrhUIwXLARodXWQ1N7Nf5rwAAzvHe7AtagADqNgMOkrwABrvP-OnWZEOV5bg1UwhF9G6f1b6DagI1ja4uDTbN6SiStVm6klpgpdtmW6S5eoxdeh1-cdgGfKBBK9Xp6oxYyz5eOSbXkB1DBtG0w0UrptnUZJ0m1W5uouVFJr0jFxW8gASkOdkRQyTL0nWTJKWqGpcpSuoNU6WMwx0Jrw2tZWVeKBUZbterYATVFjh06iQCajqZia1p2g60WXu6no-n6G0KyGkD3VGGYWmrKWJtmKZ5vgGv8kmOaplKr02YT1GmPzdkvYQ_y0xRltjrSL1uwJkAVnMIs_uz8Gs97vM29RQu6R7gl-hLYfe8MUuII6MX2NHMdK76Zqp1ayfe1r0aq4EyWRkna0x_6uu5mmBvpf8RfWd7r0k_KlyGKgc3W87XtzC5oGIy7fPO7V4BRPOWhaMkyC4GCwIWQeDLLkCzi8ZPC_OKEVLalWwpYrWNINoPTZaHPU-guCvH2FBg7_GRB4NaJ5-0EOrOljEcQJLeySpBkLHMPJF9DuFoGynrMqNoHxUbDG1ASe2-BabDGfroV-SQUjpGXCLMcwBTzYEgL_MK5F96liijeBUJ9nBBVEHQdIOF_74JPCgPQTlY5vmZGYAAosgVSN5uRWVobFcchk2IcVMtwgYaMmyNkgESLQtoPwij5OxPQAIGAUBoBPcQ0lbRsK9Dpb2DIpAyL2HIjsijIb5Q6KoxA6jvRzkHiPYY1ZyFMi0VsOsujZFjEMUo306oGxuW0XWOxOI8QcjrO2Y4IQRCBhEAAL08dpKIVjwHDBCWEiJ0SJ4B0gFFFwREOhpDSPQpxO9lQChYWw1ufJOGOy2O9DoWS6BlC8RaDOBoADki13jNOKK0ls7SAINP5DnFpokOnNOaQBUK5QnRx0wpQgetdBL6UzIhWEjsBJRSWexLcConRLNISFShwji5Z3WYw4p-hWHsLfBUsOAlanY0vM0VoJdIB_jKDeaZuFZnF3EavOZXyFxzPEdqUR_QS5Aqwc7GWjkrFaHbHo_YfZtQ93HEyQkNiRaoAAIK4F8OQZhlBbTBDSQeJFG9JzSHHji7yIRfDoEkOQVFglMXSUwPnB6kYEWlhJX4jw5LmWsqjAyhcwxx64DhX00i9gvA-hzqtWx8DEjv3SCKuFpQyi0lInCeEcQrwagiCXUWLQ8KQG3kqOkzRgJJxLnHMWewJXwlsfLNO_pCrbntXncMbKzRSvFPy7WbrjZ6wrsUKus4657wKaa34zcyl7DEYAuxJqgH7DERI4YvobBiolpAQwAg7C-g1fxOV5B4gKqQWkdNdBVUmkwpAAAtC8nNebRUxTjci-UZNCn7EpgIPp3I3UMy2kzEWW0jTCwNQOyWLppaNqlM22W2hHV-idBnFWOdDaUw9QmUuyZy5SnXQG3dLhrRLPXUsgsNrsDwlbRvZE9jya733gk8FwhIyZqtNm3Ns6C3Xx_B-ptpFIByT_V-4GBgRBg1CBDKGMM4YwOAy4OdPDkaIHySWItJa35lsHC-lV5Rq2tFrZ0GdCGNVgobsqDtkbu29s1GC-Y4tB0w2HchDQw6L2Wkna6djcc5a5QVuxldoZfXRljMJnWO7TbpidAeyT24MHpmI_mmK57zSXo9h3eNm8azkeTRA8Nqghz4DfbK6YxaEGKrSAZlwuGui4E1b4ztWz71FJZGyEINGeQDsgOJZmdn4Q3q3jp1AKbw3YIxdJDl6HzNloJpfSAGLWKsX_OvZzdIampZVFTcpmp_nDD1LRFjY6l0Mc49LSZU63QLr406kNq7hPrpzuJk2-t91l1k8e6Cp7oIqddqWVtmnb2JocfEoVvIqBUGCMZvVEak1Occ9R6m_aGPtCY1jUdbHVMcZtBV7jFXeObTNKJZdi66ubpSg1sTwwZMtek21_WHWpOLO68RV23tr3csG0FkLT6dCGGcOFxAkXwUCzbUU4IkNGCCt-84BR1WiXaiihnIEf2eHDXyUF055yY2YJy3B-mmYM6P1LEj7AKOpgk5R0BCKeDRHh3AZyiFFPnCCuJKT5wABVcgGcgeI8Xcj5wUw0cpfm0UM5pSPNWXmeYI7BPF1E4dXD_nPCmd1MAtTwFpYCSryeYixnfO2dQsfdMFHnOM4srO-y9JvPFcG8F-jjLmPxfU0lz7aXx24eAfkqJi38uqubSV-T_XlO1cAI17TnXDOQcq8FWMc38YUqw82jzk8Xh4BPXtyLkpqlnd45_DLxpJ2gN9I3fH1KzxxyVF5YgOPBdwi-9T1zIqoe0PfLp7l4HdlVbwFRRI0AEBoBwEUOgSAAA1EQ-BSqkFIGP-8gZn2_2cBIKQnAeB8FVngQgshoDyCHxgMfE_pvaqMCYMwS8uCrVJTwUxMwoiz3Ms4cqgoGj4HKoOloStRB6FrU_xoRrL_VDqGf1G0AUEAEEo2kHbGYWCEaFBGaQAGIhQ1xRl_M6xRcvBwDIDoDF5mk0DkCHNxgrABBDAeEGRMDxRsC4CRVa1CDiDRlvYUDFh7xbQsQAAhYg0wQWccMgmA8heAqg20dgqQPAmbPQNgObcYbg7A8aMQ4QwBWkAxDAocKA8g2A6oeWT_OgWtW0PASMWQ8cVUaVYTRQugZQng8wZpSmQwi3PQhkGAwwYw0wqQuwmwusNhOgOlWLIcBwrA1QtwulWtbBFwxYPwqQZhXAGwbwlQ3g8lEwfwitII8YEI8gAEYIE8dLRYSQ3w2IqQWtEkLIZAhg8YFseCAQMwLIV9PkADDoEZQo6QYo3MMolKAmHDapSAGo2olsAwn1C3RvWcDo5YVibAVRAxVwEIVAckaFRJLw4oyomKckQtOYLlRYGgugaQY8RAGEPTVsbBcqcgIg8hRxQBFYtYwMGEKYGox9GUbUYkQcKURw0EdgKgd0WhVAGcQ40zPQSAQgKIqYPYeAQwHg6oW4lwe4-xagVtISY1XfN4r4nw1Y3fAxclXAFRF4t4-EJFb4ngyYyATI8hf4YIE_MIabdDK8TE3iX4oYgE3iaQAARxhBSlCQJIenMHxNygelbQxLhOxJbBFU7AxXMEIGeMAkcEQAACZ4YS5tURYoDwD4BgT8BQTzCRBmkRTupgC5gRAoDqgXjESRUwQxT-tYTyUhAzpLAoDDSkVpSiAjdFxeSMVjgBTKskAJSY4liii7THT7A0gAxUA0gRSU1RseTkS-S8ZPTtBEAXTvY3S6iPTBTvSsg_TnS5xRstBwjUBJQKjlRzAvAN8Iz-JMl20OgczVAIChw4VxiQJvYYhIAAARb4pCQMNQKCAgVAeEUqUYYIY1HTRElkbIQxVkOzYkmbeQtxaQQcHMw8QEDsiebs0c3s-Rac1tBiWo0Q1qWpeeCEHJToYszfaHQxOHeYh5SAdBcodfEsvcgHckGtPJeEAshIdwsAnJDmLwDAVUfQZWW0VKZpIZSAcyd1UvX83EEYfAVKRRSc3kSAe0P3BWaQG872BqHcxACYFHRPBWckGGRC5C_7CLbSTQJ5eje8kQR8loAHEWeCDAP8jOWCr4cRKBV3TC2PYTVCmJSMmOUwQi4itIUinOMi8UCiwcaC30WC-ESBDKei3MpYJlavYTckR-ditkIi9oLi6SXil838gSniwIYC0C5AcC0wSC5gKitIIeW_OsVc8YS-DFOgMDAQ9cSzAoWteSh8v0pyoi-zEQ5JUQVJKYTCpJZ8FJGJeEBCiSxii3ZitJVivUMy9gVqBE0c8c7ASc8wnOP7DOPQ0Sh2eEKKxgmK8YOKvQJEieZpFKrnRddKoKn8TCvc8K9CtoKqg3S83CrKhkcy7UpQXU5E8wxstKpcqBPCuYbKiy3Ktq9AREhKpK5pbqsqpc8NWBdBY4BgbAUqFgfAAMKSK8RodAagUNDUngPpcYcHKGFbDoOGIc72KUgwWU-UxU5pAwFU5pUolAZ8HI_QAQUqRyl0YIXIo-TQoUUqAoyU3QK8AQWwK60kEEuE8w2wFUtITa1Aba2wZLEuEG3ARkGKDc8k6o1CjQ9FL4iUOgSMaQeLZE38_0EQPs1S4YaQam5pN1FGiYRAY4TIcgNoAAZn7X0GNIEFNJRsNNnIKtANNIMCXNhODH6qrPQQBHlIwRbKWxcyz2xyuXwous8nSLyuushtuv0HuseqyH8NevevYAJXwG-uXl-qWoBqeQMEtHpAY1mpTiBugu0PPBFBrLBruM1uhvsGaSVmdroPVPoPwvxwLzh1YsDgMjtNDN9uwBdprO9oDFyPllrVQDpPMj0MDmjtjpGtQA6qKp6rdSbD6oLp1EztduztzvMNSumuLsGpjODIxSjvlmdtdvjuQGTtTsHHTs7nwp7qfRLmtsFtxDBCbpjtdvctBWVsdpzldvdohqiKhtwHupzn9uLuDv6WEzDoGpvgYqkprzZVkvFpjlrqDNwD5IdOnrjpwLbsIkUGUjpS7rywYiPtLprPLtHL1OKuEyVktpLgyugRruCpLLGABz3qjAPuLozpHqzvytWI_pzm_sNMfuLoLEYnwoHpNKHovs1WLqlLjhnrVqBPBoVM9sXu9rjmQOrKeW3pCsxWxSsDxU-pYs0EoZLkiDwdfp0EZuZraDSFFJvJYZjifvOsdrjiZooFnuIfnuaXTIoHutEeZofu21dDEZkHXJ-ttotDjgDrmHYa5tNPkYoEQerLXrQhcE3sBuLSvCWRrJEEPAkZuvCMPHuqWUUfgoWQtCWXMaPusdsbRsvAxoFxqSeyQggc7iLt7ryx8cPHGkjESDTIzJ4agi3DgoiaEZ1wiaUcIDLsHoniicQePOADSfmE5pyY3AqzHtCbmClKSNQHwYrw1qka9smuyOLWQLb1_JadqdfqglKn0EEESaWr6YEGMvafQe5qHpqYqfafWkduw0QEjDYOsuXwIZPrPvMEmcvoTrmd0IrA9gthfUWY4LfoFs6uaW2bab2e2cOakGOdgdOaSNGTbzowGtDzyyDsqpoaxRxQYeNrSU9281uwk31nhleYdssa-PCLoGuc4IjvrodI2dbtrXGYucDgrWhducKvMPiN2dRchfRZgcxeafcKEM1V1Azsdqs3wGhfANWYbvWc6Zbqvscr6ZblrUDDoBRYGspfxZ1PftOcpc5by25cEJkAJY_oedXlBfDhb1YeLtXrz0Beawri8fywxY_uSFUR_sEcHjcmLurIxQwa2mbNoGLv5tgcNfVDCDdS1xEvhHRNoCiSanvzoE7D6d7BAnhGrLrIEPG1yE9diHlUw1SGGxtKfRbGwHGbCJsFP1qXSUAVxPMLgNqWxZOI2PwDaBas8sddwB1foI9gABJzDpBDARAlI8BAxRky3WBAd1ApA_ATQDZwUcholmpeJXWgCtcq3AxzCW4LbcEwUoof8YJIBSoPwlrLhnXpA_iqSSFcSWDIxX9E0HJH83WX87N8kotS0P4WwL5HXW3nB23GhVUh2JwIQZpcRx3p3ATtDcBCbUA5SEhEA_B8ARAqAGAyIN3drzAh2TNe7qymABLIxSdtBxGujgLIAmBX333rRyoVrggkIIj5zIRgKxxYOuiw5jG6AMP0FqBkArAwUqRqyT3IO32eFclP3SxiOX3SOpgWgABWYaYaAQc8G8unFB0bYeVscQLnQgKN5k-GasgyXdlt51w9m4SswFNFFsAYoYwMEYrcbIeYn9RNSvW4vYcgeZx-AcfuLY4c1xE53AZhSc5weT9zZpFYlUr44z2KHkQ--ZY1fAazxkLIdsDF8EPD4tLFyFxh_2oDRz6kiaVzgl9zqwcY5pAx8gUZd4_AuokoxozM7AKoqzgLlzocJYcgBT0ia1t1SEgUpzwLtL4L4EDzsLitHz8IPz_L1L-E3lgqkLzz5pFxyyOztiuseoiUeL5o-ZpL_zkhAr1YqwTLmKUJm-AyOLvppo_AFoy8FVwBdr0oibyMLr19VoloFoGi3-5BkS97RYLonOQqoz3iUziwH20Qb0Sz3rmzs6n2Bzqr_QVzhyUEtz4r0L5K5AKw0vFsHq6LmbTo977ogCjoENYuy75z-7tLx7uEjF8am4T-j7guL76u3-8JgaubvbowmpWiLKtNO7h751p7sV059Hi3RHuHOg7LuuHbxIlpvjg76z478wpAMQL0C76zq5OnUHgQQcazustatkCYunAyCN1wPjmNsyrN1JDTb5cAQT4JJQzW6oCgeAXjyFjFFpytkVQ7kztxUYk7pn8760S7q5aszn7n3iXn5AdaiYmIcOGX9BG1gBbEqRXELFUVPkcwIxQJEzF-Ld9IZ33AV3uFam2CiTwBJg1gkVuno7nXhTxns7lnw3tn3HN1U3y7i3q3w03Lsb2Ymb674YT3tERNGY21ROAyYn0vfJoT--OgXY_YiYzbynkbNFf3zwugS8gvkIX98cJI1vqP7XvQXXuP5n1nzG2z551Pnn1ay3_nqX72DviwKXm1zXNFSRD8FI0kCwefrvhkJI9frIPvugBn074fxP0fhY72Cf83qfjP55_P1EdzRfjuTjyCj8QY8eD3-_okmeOXkwhX0A-Zvjmr2JaRdIMmvenjHzM768E-yXQJmPw55Ocueafa_jP2eaZIYobQD2KQXl5SMk2MUFNusU2LtN5-QMGbmCi1zgJn-q_XEHWXg5GZ3eW_IcmawP5H8oBI_WAXnxu55cUu4PGru1VHL1cwuArZrjg0dqMwYBqxfrhO0HDOAnukPKIpaHtpz9P-lgPzL_QnqdwQsVAwzpCzFQMDD6TAsAdHwH6x8cClJeILQVP7sCWuWfNruN3KJwpv0Ig8FmINB6SC5BgJdwdSRNDF1iBWaMbg0UW4OCW0prWwQEPsE58eEFxbVo3xi4jkDOWvQ_hAL17x82BV3FrvZy4F9dquz3RfK92aTYt3ixOERhVimCuDshngkhBUNWJ0kQgkYRkmyVPxpBnQyjZmv_EDixwKsp7XiHx0YZPRsemTJCoTyKpldjaehUsHHGKT_EKyG3cROoNESB1AUT6FvlN2670DP-2_VLLnQSFH8igUw0nBy0sFpDnmNgxYPN064rCVuufA8BY0-IuDceEPfHlDyqEKD2mcCMzL729JmD9hVaXAJhFrQTJQhHXQIRENwRPJfB76fwUCPKLLdSMozQEQt2hEXCkuNRNjmQKl4GDkS2wpIUPwN7iD2e7zW7twKC61d4SL3Bruc2EF7MSSAw0ofcNWLPDnhNQhkt8UJLpBTG-AKhO0IGExM4mYwBJmkAJRDEvQrHLkRMOIQmFvOxtPoVSO5FDCvONgcrgRw6GuhJhzcckIMGebsdGIHscgdqP3haCZE42SbGsNxBoh9wqDPTvoj5aGdwBxgyASkMOFK0t6e1MoTwOzozhjqbRchj9xuFXg7hRIh4dIN_7yDvBGTcEfky1FZVcuro4kUoA9FDpwuFWFRnQXSFgtbhb-GMYGO6FPDHhIYnNmGOUEsxkGfdGONGLpFSDsx8gorrkIa6Z0ouHA4Rs4IzHliGRuYwEqGIibhjQm7Hbbna33i94wApABAC8UgAbkhQ0kEIFPgHwbIvQ9AJgNmn-CeQVigFLaGvkPDj5lq-w_YlvhIAD5YAVwBoGeUIBDiDx6BdcRPjkAKARxY4x9iEEPxA1j8zJRCtaHPGlR3Ak4d4rYVzI-VcytRV8VMFfH20b4qnUkOp006pjqyzCc8MFHgARFtgL_XEH6zQZ1hMK_vOFAYgUQeIZyziM8Pp3cTGJVBVtOsK-OkD-9A-7vBkB33ImxoQhiwEif7z45ipKJ9_RiXyEr7ESNxpEj8DCIol1gO-PEmichLomcT_eNAwzExL4n38xJ1mNibRPGD0TpEKQCbHQL2CJoO-ho5SXCnYnCSJ8XE3EK30vLMTTR-AAydJG0nySRJa_VIkEkWAd89-VrOSWsUsm4g3-2E2yff1cmSsw0_rWsnyJQCpRlg4SNQEyFqIuIrRC5LCYmkQqaDOAuE8KfhOUQ_jVATo8cCRPib-TyyUU3Mo2FTRUTkScKKYOKkTgyoUpX4kssqgokRDJUG9KAM2A76uTCpsbfEYAkwpjwZywQqkLlJYk6DssxqPwSCNKkoSJKFaN9NaHVTBDFhUAfiUiN6kqCxpA05PjciGklltmo01TLCMWHTTLKKlWCOEEWkzZMKYWHCjKDqn397JhUvaXAIOkSU8iC_E6XvA77SSVJOOZjMn2ukllKWxmWqQ9Pv4aTjRewNYIOjH7vTN8pgI0c9JUE5TwAEicAEAA&debug=false&forceAllTransforms=false&shippedProposals=false&circleciRepo=&evaluate=false&fileSize=true&timeTravel=false&sourceType=module&lineWrap=true&presets=es2015%2Ces2017%2Creact%2Cstage-2&prettier=false&targets=&version=7.7.7&externalPlugins=babel-plugin-minify-simplify%400.5.1%2Cbabel-plugin-minify-dead-code-elimination%400.5.1%2Cbabel-plugin-minify-replace%400.5.0%2Cbabel-plugin-remove-template-whitespace%401.0.2
class Model {
  constructor(initdata,content,conf,commitHandler) {
	//console.log("parsing data for:"+conf.cfName + " = "+initdata );
    this.conf = conf;
    this.initdata = initdata;
    this.todos = JSON.parse(initdata) || [];
    this.parseContent(content,true)
    this.commitHandler=commitHandler;
  }
  clear(){
	  this.todos = this.todos.filter(todo => todo.fromTemplate)
	  this.todos = this.todos.map(todo =>
	  		true ? {id: todo.id, label: todo.label, checked: false , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate} :{}
	  		)
	  this.commit(this.todos)
  }
  _getCFName(){
	  return this.conf.cfName
  }
  
  _parseNote(line,item) {
	    var nText = line.substring(line.indexOf(">")+1);
		item.note = (item.note ? item.note +"\n" +nText : nText);
		return true
	}
     
	_parseLine(line,parent) {
	    if(parent!=null && line.match("^ *>")) {
			if(this._parseNote(line,parent)) {
				return parent;
			}
		}	
		var lineParts = line.split("\t");
		var text = line;
		var mandatory = false;
		var checked = false;
		var newItem = true;		
		if(lineParts.length>1) {		
			if(lineParts[0].startsWith("[X]")) {
				checked = true;
			}
			if(lineParts[0].endsWith("!")) {
				mandatory = true;
			}
			text = lineParts[1];
		}		
		if(text.trim().length==0){
			return null;		
		}
		var id = text;
		var toReturn;
		this.todos = this.todos.map(todo =>{
			if(todo.id === id){
				newItem = false;
				toReturn = { id: todo.id, label: text, checked: checked , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate}
				return toReturn
			}else{
				return todo
			}
			}
	    )
	    if(newItem){
	    	toReturn = {
				      id: id,
				      label: text,
				      checked: checked,
				      mandatory: mandatory,
				      fromTemplate:false,
				    }
			this.todos.push(toReturn)
	    }
		
		return toReturn;	

	}
  
  
  load(content){
	  this.parseContent(content)	 
	  this.commit(this.todos)

  }
  parseContent(content,noreset){
	  if(!noreset){
		  //console.log("parse & reset");
		  this.todos=[];		  
	  }else{
		  //console.log("parse in / no reset");
	  }
	  var lines = content.split("\n");
	  var last;
	  lines.forEach(line => {
		last = this._parseLine(line,last);	
	  })
  }

  bindTodoListChanged(callback) {
    this.onTodoListChanged = callback
  }


  
  commit(todos) {
    this.onTodoListChanged(todos)	
    this.commitHandler(this.getSerialized())
	
  }
  
  getSerialized(){
	  var text = "";
	    this.todos.forEach(todo => {
			   text = text+(todo.checked?'[X]':'[_]')+(todo.mandatory?'!':'')+"\t"+todo.label+"\n";	
			   if(todo.note){
				   var noteLines = todo.note.split("\n");					 
				   noteLines.forEach(line => {
					   text = text+ "        >"+line+"\n";	
					  })				  				   
			   }
	    });      
	    return text;
  }

  getTodos(){
	  return this.todos;
  }
  
  isAdminEnabled(){
	  return this.conf.adminPermission;
  }
  isAllMandatory(){
	  return this.conf.allMandatory;
  }
  
  addTodo(todoText,mkemandatory) {
	  console.log("addTodo:"+todoText)

    const todo = {
      id: "" + (this.todos + 1),
      label: todoText,
      checked: false,
      mandatory: mkemandatory,
      fromTemplate:false
    }

    this.todos.push(todo)
    this.commit(this.todos)
  }

  editTodo(id, updatedText) {
	  console.log("edit:"+id+" ->"+updatedText)
    this.todos = this.todos.map(todo =>
      todo.id === id ? { id: todo.id, label: updatedText, checked: todo.checked , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate, note:todo.note} : todo
    )
    this.commit(this.todos)
  }
  
  replyTodo(id, updatedText) {
	  if( updatedText && updatedText.trim().length==0){
		  updatedText = null;
	  }
	  console.log("replyTodo:"+id+" - "+updatedText)
	    this.todos = this.todos.map(todo =>
	      todo.id === id ? { id: todo.id, label: todo.label, checked: todo.checked , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate, note:updatedText} : todo
	    )
	    this.commit(this.todos)
	  }

  deleteTodo(id) {
	  console.log("deleteTodo:"+id)

    this.todos = this.todos.filter(todo => todo.id !== id)
    this.commit(this.todos)
  }

  resetAll(){
	  console.log("Reset ALL")
	  this.todos = this.todos.map(todo => 
	  	true ? { id: todo.id, label: todo.label, checked: false , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate, note:todo.note} : todo
	  )
      this.commit(this.todos)
  }
  
  toggleTodo(id) {
    this.todos = this.todos.map(todo =>
      todo.id === id ? { id: todo.id, label: todo.label, checked: !todo.checked , mandatory:todo.mandatory,  fromTemplate:todo.fromTemplate, note:todo.note} : todo
    )
    this.commit(this.todos)
  }
  
  countAll(){
	  return this.todos.length;
  }
  countChecked(){
	  var checkedCount = 0;
	  this.todos.forEach(todo => {
		  if(todo.checked){
			  checkedCount = checkedCount+1;
		  }
	  })	       
	  return checkedCount;
  }
  
  countUnchecked(){
	  var checkedCount = 0;
	  this.todos.forEach(todo => {
		  if(!todo.checked){
			  checkedCount = checkedCount+1;
		  }
	  })	       
	  return checkedCount;
  }
  countUncheckedMandatory(){
	  var checkedCount = 0;
	  this.todos.forEach(todo => {
		  if(!todo.checked && todo.mandatory){
			  checkedCount = checkedCount+1;
		  }
	  })	       
	  return checkedCount;
  }
  isMandatoryChecked(){
	  var mc = true;
	  this.todos.forEach(todo => {
		  if(!todo.checked && (todo.mandatory || this.conf.allMandatory) ){
			  mc = false;
		  }
	  })	       
	  return mc;
  }
}

/**
 * @class View
 * 
 * Visual representation of the model.
 */
class View {
  constructor(conf) {
	this.conf = conf;
	this.parentIframeId = "checklist-frame" + this.conf.cfName 
    this.app = this.getElement('#root')
    this.form = this.getElement('form')
    this.input = this.getElement('#add-input')    
    this.submitButton = this.getElement('#add-button')
    this.stats = this.getElement('.stats')
    this.todoList = this.getElement('.checklist-body')
    this.makemandatory = this.getElement('.makemandatory')
    this.menu = this.getElement('.menu')
    this.actionReset = this.getElement('.action-reset')
    this.actionEdit = this.getElement('.action-edit')
    this.actionClear = this.getElement('.action-clear')

    this._temporaryTodoText = ''
    this._temporaryReplyText = ''

    this._makemandatory = false

    this._initLocalListeners()
  }

  get _todoText() {
	    return this.input.value
	  }
  _resetInput() {
    this.input.value = ''
  }
 
	 
	  
  createElement(tag, className) {
    const element = document.createElement(tag)
    if (className) element.classList.add(className)
    return element
  }

  getElement(selector) {
    const element = document.querySelector(selector)
    return element
  }

  _addFA(el, cl1,cl2){
      const iEl = this.createElement('i',cl1)  
      iEl.classList.add(cl2)
      el.append(iEl)
      return  iEl
  }
  
  _addFAS(el, cl){
      return this._addFA(el,"fas",cl)
  } 
  _addFAR(el, cl){
      return this._addFA(el,"far",cl)
  } 
  
  displayTodos(model) {
	var todos = model.getTodos();
    // Delete all nodes
    while (this.todoList.firstChild) {
      this.todoList.removeChild(this.todoList.firstChild)
    }
   
    this.stats.textContent= " "+model.countChecked() + " / "+ model.countAll()+" ";
    var tooltip = "Items marked by '!' are mandatory and they have to be checked.";
    if(model.countChecked()==model.countAll()){
         tooltip = "All items are checked.";
    }else if(model.isMandatoryChecked()){
        tooltip = "All mandatory items are checked."
    }else if(model.isAllMandatory()){
		tooltip ="All items are mandatory and they have to be checked."
	}
	this.stats.setAttribute("data-tooltip",tooltip)

    this.serialized = model.getSerialized()
    if(model.isMandatoryChecked()){
    	this.stats.classList.remove('mandatoryunchecked')
    }else{
    	this.stats.classList.add('mandatoryunchecked')
    }
    if(model.countChecked()==model.countAll()){
    	this.stats.classList.add('allchecked')
    }else{
    	this.stats.classList.remove('allchecked')
    }

    // Show default message
    if (todos.length === 0) {
        const tr = this.createElement('tr','polarion-rpw-table-content-row')

      const ptd = this.createElement('td',"messagetd")
      ptd.textContent = 'Checklist is empty. Add a first item  ...'
      ptd.colSpan=3
      tr.append(ptd)
      this.todoList.append(tr)
    } else {
      // Create nodes
      todos.forEach(todo => {
        const tr = this.createElement('tr','polarion-rpw-table-content-row')

        tr.id = todo.id

        const checkboxTD = this.createElement('td','checkbox')  
        
        if(todo.checked){
        	this._addFAR(checkboxTD,'fa-check-square')
        	checkboxTD.classList.add('checked')
        }else{
        	checkboxTD.classList.add('unchecked')
        	this._addFAR(checkboxTD,'fa-square')
        }                   
        tr.append(checkboxTD)

        
        const mandatoryTD = this.createElement('td','mandatory')  
        if(todo.mandatory){
        	if(!model.isAllMandatory()){
        	this._addFAS(mandatoryTD,'fa-exclamation')
        	}
        	checkboxTD.classList.add('mandatorycheck')

        }else{
        	if(model.isAllMandatory()){
            	checkboxTD.classList.add('mandatorycheck')
        	}
        }    
        tr.append(mandatoryTD)


        const labelTD = this.createElement('td','label')
//        if(!model.isAdminEnabled()){
//        	labelTD.colSpan="2";
//        }
        const labelSpan = this.createElement('span','labelSpan')
        labelSpan.textContent = todo.label 
        labelTD.append(labelSpan)
       // if(todo.note){
            const noteDiv = this.createElement('div','note')
            if(todo.note){
            	noteDiv.textContent = todo.note 
            }else{
            	noteDiv.style.display="none";
            }
            
            labelTD.append(noteDiv)
        //}
        tr.append(labelTD)
             const actionsTD = this.createElement('td','actions')
	        actionsTD.nowrap="nowrap"
	        tr.append(actionsTD)
	        	const replyButton = this._addFAS(actionsTD,'fa-reply')
		    	replyButton.classList.add('reply')
		    	replyButton.classList.add('action')	       
	        	
		    	        if(model.isAdminEnabled() && !todo.fromTemplate){

		        const editButton = this._addFAS(actionsTD,'fa-pen')
		    	editButton.classList.add('edit')
		    	editButton.classList.add('action')

		    	const deleteButton = this._addFAR(actionsTD,'fa-trash-alt')
		    	deleteButton.classList.add('delete')
		    	deleteButton.classList.add('action')	
		    	     }
	        	
        
        if(!todo.fromTemplate){
        	tr.classList.add('local')

        }

	

        // Append nodes
        this.todoList.append(tr)
      })
    }
    
    resizeParentFrame();

    // Debugging
    //console.log(todos)
  }
  
  
  _openEditor(text){
	    this.getElement('#textedit').value=this.serialized

	    
	    $('.ui.modal').modal({onHide: resizeParentFrame }).modal('show');
	 
	    var frame = window.parent.document.getElementById(this.parentIframeId);
	    console.log("_resizeParentFrame:"+frame.contentWindow.document.body.scrollHeight);
	      if(frame) {
	            // here you can make the height, I delete it first, then I make
				// it
				// again
	    	 // frame.height = "";
	    	  frame.height =  "500px";
	      }   
  }
  
  _cancelEditor(){
// this._resizeParentFrame();
  }

  
  _initLocalListeners() {
	  if(this.conf.readonly){
		  return;
	  }
    this.todoList.addEventListener('input', event => {
      if (event.target.classList.contains('editable')  && event.target.classList.contains('labelSpan')) {
        this._temporaryTodoText = event.target.innerText
      }
      if (event.target.classList.contains('editable') && event.target.classList.contains('note')) {
          this._temporaryReplyText = event.target.innerText
          if(!this._temporaryReplyText){
        	  this._temporaryReplyText =  " ";
          }
        }
    })
    this.makemandatory.addEventListener('click', event => {
      if (event.target.parentElement.classList.contains('makemandatory_checked')) {
        this._makemandatory = false
        event.target.parentElement.classList.remove('makemandatory_checked')
      }else{
    	  this._makemandatory = true
    	  event.target.parentElement.classList.add('makemandatory_checked') 
      }
    })
    this.actionEdit.addEventListener('click', event => {
	      event.preventDefault()
	      this._openEditor(this.serialized)
	    })
// this.getElement('.cancelEditAction').addEventListener('click', event => {
// event.preventDefault()
//	     
// })

		 
  }

  bindAddTodo(handler) {
	  console.log("bindAddTodo...");
    this.submitButton.addEventListener('click', event => {
      event.preventDefault()
      if (this._todoText) {
        handler(this._todoText,this._makemandatory)
        this._resetInput()
      }
    })
  }
  
  
  bindResetAll(handler) {
	    this.actionReset.addEventListener('click', event => {
	      event.preventDefault()
	        handler()
	    })
	  }
  
  
  bindClear(handler) {
	    this.actionClear.addEventListener('click', event => {
	      event.preventDefault()
	        handler()
	    })
	  }
  
  bindLoad(handler) {
	  this.getElement('.applyEditAction').addEventListener('click', event => {
	      event.preventDefault()
	      var text=	    this.getElement('#textedit').value
	        handler(text)
	    })  
}
  
  
  bindDeleteTodo(handler) {
    this.todoList.addEventListener('click', event => {
        if (event.target.classList.contains('delete')) {
        const id = event.target.parentElement.parentElement.id

        handler(id)
      }      
    })
  }

  bindEditTodo(handler) {
    this.todoList.addEventListener('focusout', event => {
      if (this._temporaryTodoText) {
        const id = event.target.parentElement.parentElement.id
        handler(id, this._temporaryTodoText)
        this._temporaryTodoText = ''
      }
    })
    this.todoList.addEventListener('click', event => {
        if (event.target.classList.contains('edit')) {
    	  const label = event.target.parentElement.parentElement.querySelector(".labelSpan");
    	  label.contentEditable = true
    	  label.classList.add('editable')
    	  label.focus();
      }      
    })    
  }
  
  bindReplyTodo(handler) {
	    this.todoList.addEventListener('focusout', event => {
	      if (this._temporaryReplyText) {
	        const id = event.target.parentElement.parentElement.id
	        //console.log("focusout:"+id+"-"+this._temporaryTodoText);
	        handler(id, this._temporaryReplyText)
	        this._temporaryReplyText = ''
	      }
	    })
	    this.todoList.addEventListener('click', event => {
	        if (event.target.classList.contains('reply')) {
	    	  const label = event.target.parentElement.parentElement.querySelector(".note");
	    	  label.style.display="block";
	    	  label.contentEditable = true
	    	  label.classList.add('editable')
	    	  label.focus();

	      }      
	    })    
	  }

  bindToggleTodo(handler) {   
    this.todoList.addEventListener('click', event => {
    	if (event.target.className === 'label') {
            const id = event.target.parentElement.id
            handler(id)
        }    
    	if (event.target.className === 'labelSpan') {
            const id = event.target.parentElement.parentElement.id
            handler(id)
        }  
        if (event.target.parentElement.classList.contains('checkbox')) {
            const id = event.target.parentElement.parentElement.id
            handler(id)
          }   
    })
    
  }
}

/**
 * @class Controller
 * 
 * Links the user input and the view output.
 * 
 * @param model
 * @param view
 */
class Controller {
  constructor(model, view,conf) {
    this.model = model
    this.view = view

    if(!conf.readonly){
        // Explicit this binding
        this.model.bindTodoListChanged(this.onTodoListChanged)
        this.view.bindAddTodo(this.handleAddTodo)
        this.view.bindEditTodo(this.handleEditTodo)
        this.view.bindReplyTodo(this.handleReplyTodo)
        this.view.bindDeleteTodo(this.handleDeleteTodo)
        this.view.bindToggleTodo(this.handleToggleTodo)
        this.view.bindResetAll(this.handleResetAll)
        this.view.bindClear(this.handleClear)

        this.view.bindLoad(this.handleLoad)	
    }

    // Display initial todos
    this.onTodoListChanged(this.model)
  }

 onTodoListChanged = model => {
   this.view.displayTodos(this.model)
 }

 handleAddTodo = (todoText,mandatory) => {
   this.model.addTodo(todoText,mandatory)
 }
 handleLoad = (text) => {
	   this.model.load(text)
	 }

 handleEditTodo = (id, todoText) => {
   this.model.editTodo(id, todoText)
 }
 
 handleReplyTodo = (id, todoText) => {
	   this.model.replyTodo(id, todoText)
	 }
 handleResetAll = () => {
	   this.model.resetAll()
	 }
 handleClear = () => {
	   this.model.clear()
	 }

 handleDeleteTodo = id => {
   this.model.deleteTodo(id)
 }

 handleToggleTodo = id => {
   this.model.toggleTodo(id)
 }
}


