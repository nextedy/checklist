/**
 * @class Model
 * 
 * Manages the data of the application.
 */
class Model {
  constructor(initdata,content,conf,commitHandler) {
	//console.log("parsing data for:"+conf.cfName + " = "+initdata );
    this.conf = conf;
    this.initdata = initdata;
    this.todos = JSON.parse(initdata) || [];
    this.parseContent(content,true)
    this.commitHandler=commitHandler;
  }
  clear(){
	  this.todos = this.todos.filter(todo => todo.fromTemplate)
	  this.todos = this.todos.map(todo =>
	  		true ? {id: todo.id, label: todo.label, checked: false , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate} :{}
	  		)
	  this.commit(this.todos)
  }
  _getCFName(){
	  return this.conf.cfName
  }
  
  _parseNote(line,item) {
	    var nText = line.substring(line.indexOf(">")+1);
		item.note = (item.note ? item.note +"\n" +nText : nText);
		return true
	}
     
	_parseLine(line,parent) {
	    if(parent!=null && line.match("^ *>")) {
			if(this._parseNote(line,parent)) {
				return parent;
			}
		}	
		var lineParts = line.split("\t");
		var text = line;
		var mandatory = false;
		var checked = false;
		var newItem = true;		
		if(lineParts.length>1) {		
			if(lineParts[0].startsWith("[X]")) {
				checked = true;
			}
			if(lineParts[0].endsWith("!")) {
				mandatory = true;
			}
			text = lineParts[1];
		}		
		if(text.trim().length==0){
			return null;		
		}
		var id = text;
		var toReturn;
		this.todos = this.todos.map(todo =>{
			if(todo.id === id){
				newItem = false;
				toReturn = { id: todo.id, label: text, checked: checked , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate}
				return toReturn
			}else{
				return todo
			}
			}
	    )
	    if(newItem){
	    	toReturn = {
				      id: id,
				      label: text,
				      checked: checked,
				      mandatory: mandatory,
				      fromTemplate:false,
				    }
			this.todos.push(toReturn)
	    }
		
		return toReturn;	

	}
  
  
  load(content){
	  this.parseContent(content)	 
	  this.commit(this.todos)

  }
  parseContent(content,noreset){
	  if(!noreset){
		  //console.log("parse & reset");
		  this.todos=[];		  
	  }else{
		  //console.log("parse in / no reset");
	  }
	  var lines = content.split("\n");
	  var last;
	  lines.forEach(line => {
		last = this._parseLine(line,last);	
	  })
  }

  bindTodoListChanged(callback) {
    this.onTodoListChanged = callback
  }


  
  commit(todos) {
    this.onTodoListChanged(todos)	
    this.commitHandler(this.getSerialized())
	
  }
  
  getSerialized(){
	  var text = "";
	    this.todos.forEach(todo => {
			   text = text+(todo.checked?'[X]':'[_]')+(todo.mandatory?'!':'')+"\t"+todo.label+"\n";	
			   if(todo.note){
				   var noteLines = todo.note.split("\n");					 
				   noteLines.forEach(line => {
					   text = text+ "        >"+line+"\n";	
					  })				  				   
			   }
	    });      
	    return text;
  }

  getTodos(){
	  return this.todos;
  }
  
  isAdminEnabled(){
	  return this.conf.adminPermission;
  }
  isAllMandatory(){
	  return this.conf.allMandatory;
  }
  
  addTodo(todoText,mkemandatory) {
	  console.log("addTodo:"+todoText)

    const todo = {
      id: "" + (this.todos + 1),
      label: todoText,
      checked: false,
      mandatory: mkemandatory,
      fromTemplate:false
    }

    this.todos.push(todo)
    this.commit(this.todos)
  }

  editTodo(id, updatedText) {
    this.todos = this.todos.map(todo =>
      todo.id === id ? { id: todo.id, label: updatedText, checked: todo.checked , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate, note:todo.note} : todo
    )
    this.commit(this.todos)
  }
  
  replyTodo(id, updatedText) {
	  if( updatedText && updatedText.trim().length==0){
		  updatedText = null;
	  }
	  console.log("replyTodo:"+id+" - "+updatedText)
	    this.todos = this.todos.map(todo =>
	      todo.id === id ? { id: todo.id, label: todo.label, checked: todo.checked , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate, note:updatedText} : todo
	    )
	    this.commit(this.todos)
	  }

  deleteTodo(id) {
	  console.log("deleteTodo:"+id)

    this.todos = this.todos.filter(todo => todo.id !== id)
    this.commit(this.todos)
  }

  resetAll(){
	  console.log("Reset ALL")
	  this.todos = this.todos.map(todo => 
	  	true ? { id: todo.id, label: todo.label, checked: false , mandatory:todo.mandatory, fromTemplate:todo.fromTemplate, note:todo.note} : todo
	  )
      this.commit(this.todos)
  }
  
  toggleTodo(id) {
    this.todos = this.todos.map(todo =>
      todo.id === id ? { id: todo.id, label: todo.label, checked: !todo.checked , mandatory:todo.mandatory,  fromTemplate:todo.fromTemplate, note:todo.note} : todo
    )
    this.commit(this.todos)
  }
  
  countAll(){
	  return this.todos.length;
  }
  countChecked(){
	  var checkedCount = 0;
	  this.todos.forEach(todo => {
		  if(todo.checked){
			  checkedCount = checkedCount+1;
		  }
	  })	       
	  return checkedCount;
  }
  
  countUnchecked(){
	  var checkedCount = 0;
	  this.todos.forEach(todo => {
		  if(!todo.checked){
			  checkedCount = checkedCount+1;
		  }
	  })	       
	  return checkedCount;
  }
  countUncheckedMandatory(){
	  var checkedCount = 0;
	  this.todos.forEach(todo => {
		  if(!todo.checked && todo.mandatory){
			  checkedCount = checkedCount+1;
		  }
	  })	       
	  return checkedCount;
  }
  isMandatoryChecked(){
	  var mc = true;
	  this.todos.forEach(todo => {
		  if(!todo.checked && (todo.mandatory || this.conf.allMandatory) ){
			  mc = false;
		  }
	  })	       
	  return mc;
  }
}

/**
 * @class View
 * 
 * Visual representation of the model.
 */
class View {
  constructor(conf) {
	this.conf = conf;
	this.parentIframeId = "checklist-frame" + this.conf.cfName 
    this.app = this.getElement('#root')
    this.form = this.getElement('form')
    this.input = this.getElement('#add-input')    
    this.submitButton = this.getElement('#add-button')
    this.stats = this.getElement('.stats')
    this.todoList = this.getElement('.checklist-body')
    this.makemandatory = this.getElement('.makemandatory')
    this.menu = this.getElement('.menu')
    this.actionReset = this.getElement('.action-reset')
    this.actionEdit = this.getElement('.action-edit')
    this.actionClear = this.getElement('.action-clear')

    this._temporaryTodoText = ''
    this._temporaryReplyText = ''

    this._makemandatory = false

    this._initLocalListeners()
  }

  get _todoText() {
	    return this.input.value
	  }
  _resetInput() {
    this.input.value = ''
  }
 
	 
	  
  createElement(tag, className) {
    const element = document.createElement(tag)
    if (className) element.classList.add(className)
    return element
  }

  getElement(selector) {
    const element = document.querySelector(selector)
    return element
  }

  _addFA(el, cl1,cl2){
      const iEl = this.createElement('i',cl1)  
      iEl.classList.add(cl2)
      el.append(iEl)
      return  iEl
  }
  
  _addFAS(el, cl){
      return this._addFA(el,"fas",cl)
  } 
  _addFAR(el, cl){
      return this._addFA(el,"far",cl)
  } 
  
  displayTodos(model) {
	var todos = model.getTodos();
    // Delete all nodes
    while (this.todoList.firstChild) {
      this.todoList.removeChild(this.todoList.firstChild)
    }
   
    this.stats.textContent= " "+model.countChecked() + " / "+ model.countAll()+" ";
    var tooltip = "Items marked by '!' are mandatory and they have to be checked.";
    if(model.countChecked()==model.countAll()){
         tooltip = "All items are checked.";
    }else if(model.isMandatoryChecked()){
        tooltip = "All mandatory items are checked."
    }else if(model.isAllMandatory()){
		tooltip ="All items are mandatory and they have to be checked."
	}
	this.stats.setAttribute("data-tooltip",tooltip)

    this.serialized = model.getSerialized()
    if(model.isMandatoryChecked()){
    	this.stats.classList.remove('mandatoryunchecked')
    }else{
    	this.stats.classList.add('mandatoryunchecked')
    }
    if(model.countChecked()==model.countAll()){
    	this.stats.classList.add('allchecked')
    }else{
    	this.stats.classList.remove('allchecked')
    }

    // Show default message
    if (todos.length === 0) {
        const tr = this.createElement('tr','polarion-rpw-table-content-row')

      const ptd = this.createElement('td',"messagetd")
      ptd.textContent = 'Checklist is empty. Add a first item  ...'
      ptd.colSpan=3
      tr.append(ptd)
      this.todoList.append(tr)
    } else {
      // Create nodes
      todos.forEach(todo => {
        const tr = this.createElement('tr','polarion-rpw-table-content-row')

        tr.id = todo.id

        const checkboxTD = this.createElement('td','checkbox')  
        
        if(todo.checked){
        	this._addFAR(checkboxTD,'fa-check-square')
        	checkboxTD.classList.add('checked')
        }else{
        	checkboxTD.classList.add('unchecked')
        	this._addFAR(checkboxTD,'fa-square')
        }                   
        tr.append(checkboxTD)

        
        const mandatoryTD = this.createElement('td','mandatory')  
        if(todo.mandatory){
        	if(!model.isAllMandatory()){
        	this._addFAS(mandatoryTD,'fa-exclamation')
        	}
        	checkboxTD.classList.add('mandatorycheck')

        }else{
        	if(model.isAllMandatory()){
            	checkboxTD.classList.add('mandatorycheck')
        	}
        }    
        tr.append(mandatoryTD)


        const labelTD = this.createElement('td','label')
//        if(!model.isAdminEnabled()){
//        	labelTD.colSpan="2";
//        }
        const labelSpan = this.createElement('span','labelSpan')
        labelSpan.textContent = todo.label 
        labelTD.append(labelSpan)
       // if(todo.note){
            const noteDiv = this.createElement('div','note')
            if(todo.note){
            	noteDiv.textContent = todo.note 
            }else{
            	noteDiv.style.display="none";
            }
            
            labelTD.append(noteDiv)
        //}
        tr.append(labelTD)
             const actionsTD = this.createElement('td','actions')
	        actionsTD.nowrap="nowrap"
	        tr.append(actionsTD)
	        	const replyButton = this._addFAS(actionsTD,'fa-reply')
		    	replyButton.classList.add('reply')
		    	replyButton.classList.add('action')	       
	        	
		    	        if(model.isAdminEnabled() && !todo.fromTemplate){

		        const editButton = this._addFAS(actionsTD,'fa-pen')
		    	editButton.classList.add('edit')
		    	editButton.classList.add('action')

		    	const deleteButton = this._addFAR(actionsTD,'fa-trash-alt')
		    	deleteButton.classList.add('delete')
		    	deleteButton.classList.add('action')	
		    	     }
	        	
        
        if(!todo.fromTemplate){
        	tr.classList.add('local')

        }

	

        // Append nodes
        this.todoList.append(tr)
      })
    }
    
    resizeParentFrame();

    // Debugging
    //console.log(todos)
  }
  
  
  _openEditor(text){
	    this.getElement('#textedit').value=this.serialized

	    
	    $('.ui.modal').modal({onHide: resizeParentFrame }).modal('show');
	 
	    var frame = window.parent.document.getElementById(this.parentIframeId);
	    console.log("_resizeParentFrame:"+frame.contentWindow.document.body.scrollHeight);
	      if(frame) {
	            // here you can make the height, I delete it first, then I make
				// it
				// again
	    	 // frame.height = "";
	    	  frame.height =  "500px";
	      }   
  }
  
  _cancelEditor(){
// this._resizeParentFrame();
  }

  
  _initLocalListeners() {
	  if(this.conf.readonly){
		  return;
	  }
    this.todoList.addEventListener('input', event => {
      if (event.target.classList.contains('editable')  && event.target.classList.contains('labelSpan')) {
        this._temporaryTodoText = event.target.innerText
      }
      if (event.target.classList.contains('editable') && event.target.classList.contains('note')) {
          this._temporaryReplyText = event.target.innerText
          if(!this._temporaryReplyText){
        	  this._temporaryReplyText =  " ";
          }
        }
    })
    this.makemandatory.addEventListener('click', event => {
      if (event.target.parentElement.classList.contains('makemandatory_checked')) {
        this._makemandatory = false
        event.target.parentElement.classList.remove('makemandatory_checked')
      }else{
    	  this._makemandatory = true
    	  event.target.parentElement.classList.add('makemandatory_checked') 
      }
    })
    this.actionEdit.addEventListener('click', event => {
	      event.preventDefault()
	      this._openEditor(this.serialized)
	    })
// this.getElement('.cancelEditAction').addEventListener('click', event => {
// event.preventDefault()
//	     
// })

		 
  }

  bindAddTodo(handler) {
	  console.log("bindAddTodo...");
    this.submitButton.addEventListener('click', event => {
      event.preventDefault()
      if (this._todoText) {
        handler(this._todoText,this._makemandatory)
        this._resetInput()
      }
    })
  }
  
  
  bindResetAll(handler) {
	    this.actionReset.addEventListener('click', event => {
	      event.preventDefault()
	        handler()
	    })
	  }
  
  
  bindClear(handler) {
	    this.actionClear.addEventListener('click', event => {
	      event.preventDefault()
	        handler()
	    })
	  }
  
  bindLoad(handler) {
	  this.getElement('.applyEditAction').addEventListener('click', event => {
	      event.preventDefault()
	      var text=	    this.getElement('#textedit').value
	        handler(text)
	    })  
}
  
  
  bindDeleteTodo(handler) {
    this.todoList.addEventListener('click', event => {
        if (event.target.classList.contains('delete')) {
        const id = event.target.parentElement.parentElement.id

        handler(id)
      }      
    })
  }

  bindEditTodo(handler) {
    this.todoList.addEventListener('focusout', event => {
      if (this._temporaryTodoText) {
        const id = event.target.parentElement.parentElement.id
        //console.log("focusout:"+id+"-"+this._temporaryTodoText);
        handler(id, this._temporaryTodoText)
        this._temporaryTodoText = ''
      }
    })
    this.todoList.addEventListener('click', event => {
        if (event.target.classList.contains('edit')) {
    	  const label = event.target.parentElement.parentElement.querySelector(".label");
    	  label.contentEditable = true
    	  label.classList.add('editable')
    	  label.focus();
      }      
    })    
  }
  
  bindReplyTodo(handler) {
	    this.todoList.addEventListener('focusout', event => {
	      if (this._temporaryReplyText) {
	        const id = event.target.parentElement.parentElement.id
	        //console.log("focusout:"+id+"-"+this._temporaryTodoText);
	        handler(id, this._temporaryReplyText)
	        this._temporaryReplyText = ''
	      }
	    })
	    this.todoList.addEventListener('click', event => {
	        if (event.target.classList.contains('reply')) {
	    	  const label = event.target.parentElement.parentElement.querySelector(".note");
	    	  label.style.display="block";
	    	  label.contentEditable = true
	    	  label.classList.add('editable')
	    	  label.focus();

	      }      
	    })    
	  }

  bindToggleTodo(handler) {   
    this.todoList.addEventListener('click', event => {
    	if (event.target.className === 'label') {
            const id = event.target.parentElement.id
            handler(id)
        }    
    	if (event.target.className === 'labelSpan') {
            const id = event.target.parentElement.parentElement.id
            handler(id)
        }  
        if (event.target.parentElement.classList.contains('checkbox')) {
            const id = event.target.parentElement.parentElement.id
            handler(id)
          }   
    })
    
  }
}

/**
 * @class Controller
 * 
 * Links the user input and the view output.
 * 
 * @param model
 * @param view
 */
class Controller {
  constructor(model, view,conf) {
    this.model = model
    this.view = view

    if(!conf.readonly){
        // Explicit this binding
        this.model.bindTodoListChanged(this.onTodoListChanged)
        this.view.bindAddTodo(this.handleAddTodo)
        this.view.bindEditTodo(this.handleEditTodo)
        this.view.bindReplyTodo(this.handleReplyTodo)
        this.view.bindDeleteTodo(this.handleDeleteTodo)
        this.view.bindToggleTodo(this.handleToggleTodo)
        this.view.bindResetAll(this.handleResetAll)
        this.view.bindClear(this.handleClear)

        this.view.bindLoad(this.handleLoad)	
    }

    // Display initial todos
    this.onTodoListChanged(this.model)
  }

 onTodoListChanged = model => {
   this.view.displayTodos(this.model)
 }

 handleAddTodo = (todoText,mandatory) => {
   this.model.addTodo(todoText,mandatory)
 }
 handleLoad = (text) => {
	   this.model.load(text)
	 }

 handleEditTodo = (id, todoText) => {
   this.model.editTodo(id, todoText)
 }
 
 handleReplyTodo = (id, todoText) => {
	   this.model.replyTodo(id, todoText)
	 }
 handleResetAll = () => {
	   this.model.resetAll()
	 }
 handleClear = () => {
	   this.model.clear()
	 }

 handleDeleteTodo = id => {
   this.model.deleteTodo(id)
 }

 handleToggleTodo = id => {
   this.model.toggleTodo(id)
 }
}


