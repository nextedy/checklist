	console.log("loading checklist...");

function setTextToTarget(checklist){

	var chlMainDiv = document.getElementById("checklist");

	var mainEl = document.getElementById("FIELD_testText");
	var targetInput = mainEl.querySelector("div textarea");
	
	
	var children = Array.prototype.slice.call(checklist.children);
	var text = "";
	var checkedCount = 0;
	var allCount = 0;
	var mandatoryDone = true;
	
	children.forEach(function(child){
	    allCount++;
		if(child.classList.contains('checked')){
		    text = text+'☒';
		    checkedCount++;		    
		}else{
			if(child.classList.contains('mandatory')){
				mandatoryDone=false;
			}
		    text = text+'☐';
		}	
		if(child.classList.contains('mandatory')){
		    text = text + '!';
		}		
		var label = child.innerHTML;
		
  		text = text + "\t"+ label + "\n" ;  		
  		console.log(text);	
	});
	
	chlMainDiv.querySelector(".chCount").innerHTML=""+checkedCount;
	chlMainDiv.querySelector(".allCount").innerHTML=""+allCount;
	chlMainDiv.querySelector(".mandatoryDone").innerHTML=(mandatoryDone?"[MD]":"");
	
	
	console.log("set value:"+text);
	targetInput.value=text;
	
    var evt = document.createEvent("HTMLEvents");
    evt.initEvent("change", false, true);
    targetInput.dispatchEvent(evt);
}

	console.log("dispatch mouse over");

	var event = new MouseEvent('mouseover', {view: window,bubbles: true,cancelable: true});
    var mainEl = document.getElementById("FIELD_testText");
    mainEl.dispatchEvent(event);
    
   // mainEl.parentElement.style.display="none";	
    
  
var list = document.getElementById("myUL");
list.addEventListener('click', function(ev) {
  if (ev.target.tagName === 'LI') {
    ev.target.classList.toggle('checked');
    setTextToTarget(this);
  }
}, false);
