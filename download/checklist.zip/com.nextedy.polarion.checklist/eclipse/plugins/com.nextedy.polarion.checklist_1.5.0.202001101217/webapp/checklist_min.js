"use strict";

function _defineProperty(obj, key, value) { return key in obj ? Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }) : obj[key] = value, obj; }

function _instanceof(left, right) { return right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance] ? !!right[Symbol.hasInstance](left) : left instanceof right; }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) throw new TypeError("Cannot call a class as a function"); }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false, descriptor.configurable = true, "value" in descriptor && (descriptor.writable = true), Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { return protoProps && _defineProperties(Constructor.prototype, protoProps), staticProps && _defineProperties(Constructor, staticProps), Constructor; }

/**
 * @class Model
 * 
 * Manages the data of the application.
 */
var Model =
/*#__PURE__*/
function () {
  function Model(initdata, content, conf) {
    _classCallCheck(this, Model), this.conf = conf, this.initdata = initdata, this.todos = JSON.parse(initdata) || [], this.parseContent(content, true);
  }

  return _createClass(Model, [{
    key: "clear",
    value: function clear() {
      this.todos = this.todos.filter(function (todo) {
        return todo.fromTemplate;
      }), this.todos = this.todos.map(function (todo) {
        return {
          id: todo.id,
          label: todo.label,
          checked: false,
          mandatory: todo.mandatory,
          fromTemplate: todo.fromTemplate
        };
      }), this.commit(this.todos);
    }
  }, {
    key: "_getCFName",
    value: function _getCFName() {
      return this.conf.cfName;
    }
  }, {
    key: "_parseLine",
    value: function _parseLine(line) {
      var lineParts = line.split("\t");
      var text = line;
      var mandatory = false;
      var checked = false;
      var newItem = true;
      if (lineParts.length > 1 && (lineParts[0].startsWith("[X]") && (checked = true), lineParts[0].endsWith("!") && (mandatory = true), text = lineParts[1]), text.trim().length == 0) return null;
      var id = text;

      if (this.todos = this.todos.map(function (todo) {
        return todo.id === id ? (newItem = false, {
          id: todo.id,
          label: text,
          checked: checked,
          mandatory: todo.mandatory,
          fromTemplate: todo.fromTemplate
        }) : todo;
      }), newItem) {
        var todo = {
          id: id,
          label: text,
          checked: checked,
          mandatory: mandatory,
          fromTemplate: false
        };
        return this.todos.push(todo), todo;
      }
    }
  }, {
    key: "load",
    value: function load(content) {
      this.parseContent(content), this.commit(this.todos);
    }
  }, {
    key: "parseContent",
    value: function parseContent(content, noreset) {
      var _this = this;

      !noreset && (this.todos = []);
      var lines = content.split("\n");
      lines.forEach(function (line) {
        _this._parseLine(line);
      });
    }
  }, {
    key: "bindTodoListChanged",
    value: function bindTodoListChanged(callback) {
      this.onTodoListChanged = callback;
    }
  }, {
    key: "_getTargetInput",
    value: function _getTargetInput() {
      if (!this.targetInput) {
        var elId = "FIELD_" + this._getCFName(); //console.log("Searching for "+elId)


        var mainEl = window.parent.document.getElementById(elId);
        this.targetInput = mainEl.querySelector("div textarea");
      }

      return this.targetInput;
    }
  }, {
    key: "commit",
    value: function commit(todos) {
      this.onTodoListChanged(todos), this._getTargetInput().value = this.getSerialized();
      var evt = document.createEvent("HTMLEvents");
      evt.initEvent("change", false, true), this._getTargetInput().dispatchEvent(evt);
    }
  }, {
    key: "getSerialized",
    value: function getSerialized() {
      var text = "";
      return this.todos.forEach(function (todo) {
        text = text + (todo.checked ? '[X]' : '[_]') + (todo.mandatory ? '!' : '') + "\t" + todo.label + "\n";
      }), text;
    }
  }, {
    key: "getTodos",
    value: function getTodos() {
      return this.todos;
    }
  }, {
    key: "isAdminEnabled",
    value: function isAdminEnabled() {
      return this.conf.adminPermission;
    }
  }, {
    key: "isAllMandatory",
    value: function isAllMandatory() {
      return this.conf.allMandatory;
    }
  }, {
    key: "addTodo",
    value: function addTodo(todoText, mkemandatory) {
      var todo = {
        id: "" + (this.todos + 1),
        label: todoText,
        checked: false,
        mandatory: mkemandatory,
        fromTemplate: false
      };
      this.todos.push(todo), this.commit(this.todos);
    }
  }, {
    key: "editTodo",
    value: function editTodo(id, updatedText) {
      this.todos = this.todos.map(function (todo) {
        return todo.id === id ? {
          id: todo.id,
          label: updatedText,
          checked: todo.checked,
          mandatory: todo.mandatory,
          fromTemplate: todo.fromTemplate
        } : todo;
      }), this.commit(this.todos);
    }
  }, {
    key: "deleteTodo",
    value: function deleteTodo(id) {
      this.todos = this.todos.filter(function (todo) {
        return todo.id !== id;
      }), this.commit(this.todos);
    }
  }, {
    key: "resetAll",
    value: function resetAll() {
      console.log("Reset ALL"), this.todos = this.todos.map(function (todo) {
        return {
          id: todo.id,
          label: todo.label,
          checked: false,
          mandatory: todo.mandatory,
          fromTemplate: todo.fromTemplate
        };
      }), this.commit(this.todos);
    }
  }, {
    key: "toggleTodo",
    value: function toggleTodo(id) {
      this.todos = this.todos.map(function (todo) {
        return todo.id === id ? {
          id: todo.id,
          label: todo.label,
          checked: !todo.checked,
          mandatory: todo.mandatory,
          fromTemplate: todo.fromTemplate
        } : todo;
      }), this.commit(this.todos);
    }
  }, {
    key: "countAll",
    value: function countAll() {
      return this.todos.length;
    }
  }, {
    key: "countChecked",
    value: function countChecked() {
      var checkedCount = 0;
      return this.todos.forEach(function (todo) {
        todo.checked && ++checkedCount;
      }), checkedCount;
    }
  }, {
    key: "isMandatoryChecked",
    value: function isMandatoryChecked() {
      var _this2 = this;

      var mc = true;
      return this.todos.forEach(function (todo) {
        !todo.checked && (todo.mandatory || _this2.conf.allMandatory) && (mc = false);
      }), mc;
    }
  }]), Model;
}();
/**
 * @class View
 * 
 * Visual representation of the model.
 */


var View =
/*#__PURE__*/
function () {
  function View(conf) {
    _classCallCheck(this, View), this.conf = conf, this.parentIframeId = "checklist-frame" + this.conf.cfName, this.app = this.getElement('#root'), this.form = this.getElement('form'), this.input = this.getElement('#add-input'), this.submitButton = this.getElement('#add-button'), this.stats = this.getElement('.stats'), this.todoList = this.getElement('.checklist-body'), this.makemandatory = this.getElement('.makemandatory'), this.menu = this.getElement('.menu'), this.actionReset = this.getElement('.action-reset'), this.actionEdit = this.getElement('.action-edit'), this.actionClear = this.getElement('.action-clear'), this._temporaryTodoText = '', this._makemandatory = false, this._initLocalListeners();
  }

  return _createClass(View, [{
    key: "_resetInput",
    value: function _resetInput() {
      this.input.value = '';
    }
  }, {
    key: "createElement",
    value: function createElement(tag, className) {
      var element = document.createElement(tag);
      return className && element.classList.add(className), element;
    }
  }, {
    key: "getElement",
    value: function getElement(selector) {
      var element = document.querySelector(selector);
      return element;
    }
  }, {
    key: "_addFA",
    value: function _addFA(el, cl1, cl2) {
      var iEl = this.createElement('i', cl1);
      return iEl.classList.add(cl2), el.append(iEl), iEl;
    }
  }, {
    key: "_addFAS",
    value: function _addFAS(el, cl) {
      return this._addFA(el, "fas", cl);
    }
  }, {
    key: "_addFAR",
    value: function _addFAR(el, cl) {
      return this._addFA(el, "far", cl);
    }
  }, {
    key: "displayTodos",
    value: function displayTodos(model) {
      var _this3 = this;

      // Delete all nodes
      for (var todos = model.getTodos(); this.todoList.firstChild;) this.todoList.removeChild(this.todoList.firstChild);

      this.stats.textContent = " " + model.countChecked() + " / " + model.countAll() + " ";
      var tooltip = "Items marked by '!' are mandatory and they have to be checked.";

      // Show default message
      if (model.countChecked() == model.countAll() ? tooltip = "All items are checked." : model.isMandatoryChecked() ? tooltip = "All mandatory items are checked." : model.isAllMandatory() && (tooltip = "All items are mandatory and they have to be checked."), this.stats.setAttribute("data-tooltip", tooltip), this.serialized = model.getSerialized(), model.isMandatoryChecked() ? this.stats.classList.remove('mandatoryunchecked') : this.stats.classList.add('mandatoryunchecked'), model.countChecked() == model.countAll() ? this.stats.classList.add('allchecked') : this.stats.classList.remove('allchecked'), todos.length === 0) {
        var tr = this.createElement('tr', 'polarion-rpw-table-content-row');
        var ptd = this.createElement('td', "messagetd");
        ptd.textContent = 'Checklist is empty. Add a first item  ...', ptd.colSpan = 3, tr.append(ptd), this.todoList.append(tr);
      } else // Create nodes
      todos.forEach(function (todo) {
        var tr = _this3.createElement('tr', 'polarion-rpw-table-content-row');

        tr.id = todo.id;

        var checkboxTD = _this3.createElement('td', 'checkbox');

        todo.checked ? (_this3._addFAR(checkboxTD, 'fa-check-square'), checkboxTD.classList.add('checked')) : (checkboxTD.classList.add('unchecked'), _this3._addFAR(checkboxTD, 'fa-square')), tr.append(checkboxTD);

        var mandatoryTD = _this3.createElement('td', 'mandatory');

        todo.mandatory ? (!model.isAllMandatory() && _this3._addFAS(mandatoryTD, 'fa-exclamation'), checkboxTD.classList.add('mandatorycheck')) : model.isAllMandatory() && checkboxTD.classList.add('mandatorycheck'), tr.append(mandatoryTD);

        var labelTD = _this3.createElement('td', 'label');

        if (labelTD.textContent = todo.label, !model.isAdminEnabled() && (labelTD.colSpan = "2"), tr.append(labelTD), model.isAdminEnabled()) {
          var actionsTD = _this3.createElement('td', 'actions');

          if (actionsTD.nowrap = "nowrap", tr.append(actionsTD), !todo.fromTemplate) {
            var editButton = _this3._addFAS(actionsTD, 'fa-pen');

            editButton.classList.add('edit'), editButton.classList.add('action');

            var deleteButton = _this3._addFAR(actionsTD, 'fa-trash-alt');

            deleteButton.classList.add('delete'), deleteButton.classList.add('action'), tr.classList.add('local');
          }
        } // Append nodes


        _this3.todoList.append(tr);
      });

      resizeParentFrame();
    }
  }, {
    key: "_openEditor",
    value: function _openEditor() {
      this.getElement('#textedit').value = this.serialized, $('.ui.modal').modal({
        onHide: resizeParentFrame
      }).modal('show');
      var frame = window.parent.document.getElementById(this.parentIframeId);
      console.log("_resizeParentFrame:" + frame.contentWindow.document.body.scrollHeight), frame && (frame.height = "500px");
    }
  }, {
    key: "_cancelEditor",
    value: function _cancelEditor() {// this._resizeParentFrame();
    }
  }, {
    key: "_initLocalListeners",
    value: function _initLocalListeners() {
      var _this4 = this;

      this.conf.readonly || (this.todoList.addEventListener('input', function (event) {
        event.target.classList.contains('editable') && (_this4._temporaryTodoText = event.target.innerText);
      }), this.makemandatory.addEventListener('click', function (event) {
        event.target.parentElement.classList.contains('makemandatory_checked') ? (_this4._makemandatory = false, event.target.parentElement.classList.remove('makemandatory_checked')) : (_this4._makemandatory = true, event.target.parentElement.classList.add('makemandatory_checked'));
      }), this.actionEdit.addEventListener('click', function (event) {
        event.preventDefault(), _this4._openEditor(_this4.serialized);
      }));
    }
  }, {
    key: "bindAddTodo",
    value: function bindAddTodo(handler) {
      var _this5 = this;

      this.submitButton.addEventListener('click', function (event) {
        event.preventDefault(), _this5._todoText && (handler(_this5._todoText, _this5._makemandatory), _this5._resetInput());
      });
    }
  }, {
    key: "bindResetAll",
    value: function bindResetAll(handler) {
      this.actionReset.addEventListener('click', function (event) {
        event.preventDefault(), handler();
      });
    }
  }, {
    key: "bindClear",
    value: function bindClear(handler) {
      this.actionClear.addEventListener('click', function (event) {
        event.preventDefault(), handler();
      });
    }
  }, {
    key: "bindLoad",
    value: function bindLoad(handler) {
      var _this6 = this;

      this.getElement('.applyEditAction').addEventListener('click', function (event) {
        event.preventDefault();

        var text = _this6.getElement('#textedit').value;

        handler(text);
      });
    }
  }, {
    key: "bindDeleteTodo",
    value: function bindDeleteTodo(handler) {
      this.todoList.addEventListener('click', function (event) {
        if (event.target.classList.contains('delete')) {
          var id = event.target.parentElement.parentElement.id;
          handler(id);
        }
      });
    }
  }, {
    key: "bindEditTodo",
    value: function bindEditTodo(handler) {
      var _this7 = this;

      this.todoList.addEventListener('focusout', function (event) {
        if (_this7._temporaryTodoText) {
          var id = event.target.parentElement.id; //console.log("focusout:"+id+"-"+this._temporaryTodoText);

          handler(id, _this7._temporaryTodoText), _this7._temporaryTodoText = '';
        }
      }), this.todoList.addEventListener('click', function (event) {
        if (event.target.classList.contains('edit')) {
          var label = event.target.parentElement.parentElement.querySelector(".label");
          label.contentEditable = true, label.classList.add('editable'), label.focus();
        }
      });
    }
  }, {
    key: "bindToggleTodo",
    value: function bindToggleTodo(handler) {
      this.todoList.addEventListener('click', function (event) {
        if (event.target.className === 'label') {
          var id = event.target.parentElement.id;
          handler(id);
        }

        if (event.target.parentElement.classList.contains('checkbox')) {
          var _id = event.target.parentElement.parentElement.id;
          handler(_id);
        }
      });
    }
  }, {
    key: "_todoText",
    get: function get() {
      return this.input.value;
    }
  }]), View;
}();
/**
 * @class Controller
 * 
 * Links the user input and the view output.
 * 
 * @param model
 * @param view
 */


var Controller = function Controller(model, view, conf) {
  var _this8 = this;

  // Display initial todos
  _classCallCheck(this, Controller), _defineProperty(this, "onTodoListChanged", function () {
    _this8.view.displayTodos(_this8.model);
  }), _defineProperty(this, "handleAddTodo", function (todoText, mandatory) {
    _this8.model.addTodo(todoText, mandatory);
  }), _defineProperty(this, "handleLoad", function (text) {
    _this8.model.load(text);
  }), _defineProperty(this, "handleEditTodo", function (id, todoText) {
    _this8.model.editTodo(id, todoText);
  }), _defineProperty(this, "handleResetAll", function () {
    _this8.model.resetAll();
  }), _defineProperty(this, "handleClear", function () {
    _this8.model.clear();
  }), _defineProperty(this, "handleDeleteTodo", function (id) {
    _this8.model.deleteTodo(id);
  }), _defineProperty(this, "handleToggleTodo", function (id) {
    _this8.model.toggleTodo(id);
  }), this.model = model, this.view = view, !conf.readonly && (this.model.bindTodoListChanged(this.onTodoListChanged), this.view.bindAddTodo(this.handleAddTodo), this.view.bindEditTodo(this.handleEditTodo), this.view.bindDeleteTodo(this.handleDeleteTodo), this.view.bindToggleTodo(this.handleToggleTodo), this.view.bindResetAll(this.handleResetAll), this.view.bindClear(this.handleClear), this.view.bindLoad(this.handleLoad)), this.onTodoListChanged(this.model);
};

var name = window.frameElement.getAttribute("data-id");
console.log("loading checklist for : " + name);

function resizeParentFrame() {
  var frame = window.parent.document.getElementById("checklist-frame" + name); //console.log("_resizeParentFrame:"+ parentIframeId+ " - "+frame.contentWindow.document.body.scrollHeight);

  if (frame) {
    //frame.height = "100px";
    var nh = frame.contentWindow.document.body.scrollHeight;
    nh < 255 && (nh = 255), frame.height = nh + "px";
  }
}

var checklistData = window.parent.document.getElementById("checklist-data_" + name).innerHTML;
var checklistConf = window.parent.document.getElementById("checklist-conf_" + name).innerHTML;
var conf = JSON.parse(checklistConf) || {};
conf.cfName = name;
var i = 0;
var mainEl = window.parent.document.getElementById("FIELD_" + name);

var findTargetInput = function () {
  i++;
  //console.log("findTargetInput:"+i + " in "+mainEl.id)
  var event = new MouseEvent('mouseover', {
    view: window,
    bubbles: true,
    cancelable: true
  });
  mainEl.dispatchEvent(event);
  var targetInput = mainEl.querySelector("div textarea");
  targetInput == null ? i < 100 ? setTimeout(findTargetInput, 100) : setupChecklist(targetInput) : setupChecklist(targetInput);
};

function setupChecklist(targetInput) {
  $("#root").show(), $("#loading").hide();
  var targetValue = "";
  targetInput == null ? (conf.readonly = true, conf.adminPermission = false, $(".cog").hide(), $("#readonlysection").show()) : targetValue = targetInput.value, !conf.adminPermission && ($("#add-tr").hide(), $(".action-edit").hide());
  var licenseEl = window.parent.document.getElementById("license_" + name);
  licenseEl != null && ($("#license").html(licenseEl.innerHTML), $("#license").show()), conf.templateId == null ? $(".action-opentemplate").hide() : $(".action-opentemplate").click(function () {
    window.open(conf.templateUrl);
  });
  var model = new Model(checklistData, targetValue, conf);
  new Controller(model, new View(conf), conf);
}

var mainEl = window.parent.document.getElementById("FIELD_" + name);

if (mainEl != null) {
  $('.ui.dropdown').dropdown();
  var editorSection = mainEl.parentElement;
  editorSection.style.display = "none", findTargetInput();
} else setupChecklist(null);